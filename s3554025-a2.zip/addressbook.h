#ifndef ADDRESSBOOK_H
#define ADDRESSBOOK_H

#include "commands.h"


/** Initialize and call main_menu() */
void init_main_menu(char * file_path);


#endif
